document.addEventListener('DOMContentLoaded', () => {
    const botones = document.querySelectorAll('.btn-filtro');
    const tarjetas = document.querySelectorAll('.tarjeta-galeria');

    botones.forEach(boton => {
        boton.addEventListener('click', () => {
            // quitar active de todos
            botones.forEach(b => b.classList.remove('active'));
            // poner active al que se clickeó
            boton.classList.add('active');

            const filtro = boton.dataset.filtro.toLowerCase();

            tarjetas.forEach(tarjeta => {
                const lugar = tarjeta.querySelector('.tarjeta-info p').textContent.toLowerCase();
                
                if (filtro === 'todos' || lugar.includes(filtro)) {
                    tarjeta.style.display = 'block';
                    tarjeta.classList.add('mostrar');
                } else {
                    tarjeta.style.display = 'none';
                    tarjeta.classList.remove('mostrar');
                }
            });
        });
    });
});