// Lista completa de preguntas para el juego de Moquegua
const preguntas = [
    {
        pregunta: "¿Dónde se encuentran las Cataratas de Mollesaja?",
        opciones: ["Torata", "Ilo", "Samegua", "Omate"],
        correcta: 0 // Torata
    },
    {
        pregunta: "¿Cuál es el distrito conocido por sus paisajes, historia y atractivos turísticos en Moquegua?",
        opciones: ["Ilo", "Torata", "Samegua", "Pacocha"],
        correcta: 1 // Torata
    },
    {
        pregunta: "¿Qué distrito destaca por sus paisajes, su gastronomía y sus atractivos turísticos cercanos a la ciudad?",
        opciones: ["Samegua", "Carumas", "Cuchumbaya", "San Cristóbal"],
        correcta: 0 // Samegua
    },
    {
        pregunta: "¿Cuál es el puerto principal de la región Moquegua?",
        opciones: ["Matarani", "Callao", "Ilo", "Chimbote"],
        correcta: 2 // Ilo
    },
    {
        pregunta: "¿Qué importante sitio arqueológico preincaico se ubica en Moquegua?",
        opciones: ["Machu Picchu", "Cerro Baúl", "Chan Chan", "Kuelap"],
        correcta: 1 // Cerro Baúl
    }
];

let preguntaActual = 0;
let puntaje = 0;

const elementoPregunta = document.getElementById("pregunta-texto");
const contenedorOpciones = document.getElementById("opciones-contenedor");
const elementoPuntaje = document.getElementById("puntaje");
const elementoTotal = document.getElementById("total-preguntas");

// Inicializar el total de preguntas en la pantalla
elementoTotal.textContent = preguntas.length;

function cargarPregunta() {
    const q = preguntas[preguntaActual];
    elementoPregunta.textContent = q.pregunta;
    contenedorOpciones.innerHTML = "";

    // Animación de entrada de la tarjeta
    const tarjeta = document.querySelector(".tarjeta-quiz");
    if (tarjeta) {
        tarjeta.style.animation = "none";
        tarjeta.offsetHeight; // Reflow
        tarjeta.style.animation = "fadeIn 0.4s ease-out";
    }

    q.opciones.forEach((opcion, index) => {
        const boton = document.createElement("button");
        boton.classList.add("opcion-btn");
        boton.textContent = opcion;
        boton.onclick = () => verificarRespuesta(index);
        contenedorOpciones.appendChild(boton);
    });
}

function verificarRespuesta(indiceSeleccionado) {
    const botones = contenedorOpciones.querySelectorAll(".opcion-btn");
    const correcta = preguntas[preguntaActual].correcta;

    // Deshabilitar todos los botones para que no sigan haciendo clic
    botones.forEach(btn => btn.disabled = true);

    if (indiceSeleccionado === correcta) {
        botones[indiceSeleccionado].classList.add("correcta");
        puntaje++;
        elementoPuntaje.textContent = puntaje;
    } else {
        botones[indiceSeleccionado].classList.add("incorrecta");
        botones[correcta].classList.add("correcta"); // Muestra cuál era la correcta
    }

    // Pasar a la siguiente pregunta tras 1.5 segundos
    setTimeout(() => {
        preguntaActual++;
        if (preguntaActual < preguntas.length) {
            cargarPregunta();
        } else {
            mostrarResultadoFinal();
        }
    }, 1500);
}

function mostrarResultadoFinal() {
    let mensaje = "";
    if (puntaje === preguntas.length) {
        mensaje = "¡Excelente! Eres un verdadero moqueguano. 🏆";
    } else if (puntaje >= Math.ceil(preguntas.length / 2)) {
        mensaje = "¡Buen intento! Conoces bastante sobre Moquegua. 👍";
    } else {
        mensaje = "¡Sigue explorando las páginas para aprender más de Moquegua! 🏔️";
    }

    const tarjeta = document.querySelector(".tarjeta-quiz");
    tarjeta.innerHTML = `
        <h2>¡Juego Terminado!</h2>
        <p class="subtitulo-quiz">${mensaje}</p>
        <h3 style="font-size: 20px; color: #1a5828; margin: 20px 0;">Tu puntaje final es: ${puntaje} / ${preguntas.length}</h3>
        <button class="opcion-btn" style="margin-top:10px; background-color: #1a5828; color: white;" onclick="location.reload()">Volver a jugar</button>
    `;
}

// Iniciar el juego cargando la primera pregunta
cargarPregunta();