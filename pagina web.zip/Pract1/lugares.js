function activarBoton(idBoton, idInformacion) {
    const boton = document.getElementById(idBoton);
    const informacion = document.getElementById(idInformacion);

    if (boton && informacion) {
        boton.addEventListener("click", function () {
            if (informacion.hidden) {
                informacion.hidden = false;
                boton.textContent = "Ver menos";
            } else {
                informacion.hidden = true;
                boton.textContent = "Ver más";
            }
        });
    }
}

const listaLugares = [
    { boton: "verPlazaMoquegua", info: "infoPlazaMoquegua" },
    { boton: "verTorata", info: "infoTorata" },
    { boton: "verMollesaja", info: "infoMollesaja" },
    { boton: "verSamegua", info: "infoSamegua" },
    { boton: "verCerroBaul", info: "infoCerroBaul" },
    { boton: "verMaleconIlo", info: "infoMaleconIlo" },
    { boton: "verGlorieta", info: "infoGlorieta" },
    { boton: "verPuntaColes", info: "infoPuntaColes" },
    { boton: "verPozoLizas", info: "infoPozoLizas" },
    { boton: "verPuertoIngles", info: "infoPuertoIngles" },
    { boton: "verChenChen", info: "infoChenChen" },
    { boton: "verTixani", info: "infoTixani" },
    { boton: "verCuchumbaya", info: "infoCuchumbaya" },
    { boton: "verOmate", info: "infoOmate" },
    { boton: "verUbinas", info: "infoUbinas" },
    { boton: "verCasaConcha", info: "infoCasaConcha" },
    { boton: "verCatedral", info: "infoCatedral" },
    { boton: "verRutaPisco", info: "infoRutaPisco" },
    { boton: "verPutina", info: "infoPutina" },
    { boton: "verCamata", info: "infoCamata" },
    { boton: "verMuseoContisuyo", info: "infoMuseoContisuyo" },
    { boton: "verCristoBlanco", info: "infoCristoBlanco" }
];


listaLugares.forEach(lugar => {
    activarBoton(lugar.boton, lugar.info);
});