
document.addEventListener("DOMContentLoaded", () => {

    const formulario = document.querySelector("#formulario-contacto");

    if (!formulario) {
        console.warn("No se encontró el formulario de contacto.");
        return;
    }

    const nombre = formulario.querySelector("#nombre");
    const correo = formulario.querySelector("#correo");
    const asunto = formulario.querySelector("#asunto");
    const mensaje = formulario.querySelector("#mensaje");

    // Crear espacio para mostrar mensajes
    let alerta = formulario.querySelector("#mensaje-alerta");

    if (!alerta) {
        alerta = document.createElement("div");
        alerta.id = "mensaje-alerta";
        alerta.setAttribute("role", "status");
        alerta.setAttribute("aria-live", "polite");
        formulario.appendChild(alerta);
    }

    formulario.addEventListener("submit", (evento) => {
        evento.preventDefault();

        // Validar campos
        if (
            !nombre.value.trim() ||
            !correo.value.trim() ||
            !asunto.value.trim() ||
            !mensaje.value.trim()
        ) {
            mostrarAlerta("Por favor, completa todos los campos.", "error");
            return;
        }

        // Validar correo
        const expresionCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!expresionCorreo.test(correo.value.trim())) {
            mostrarAlerta("Ingresa un correo electrónico válido.", "error");
            correo.focus();
            return;
        }

        // Mostrar confirmación
        mostrarAlerta(
            `¡Gracias, ${nombre.value.trim()}! Tu mensaje está listo para enviarse.`,
            "exito"
        );

        // Limpiar formulario
        formulario.reset();
    });

    function mostrarAlerta(texto, tipo) {
        alerta.textContent = texto;
        alerta.className = `alerta-contacto ${tipo}`;

        alerta.scrollIntoView({
            behavior: "smooth",
            block: "nearest"
        });
    }

});
